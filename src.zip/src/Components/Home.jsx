import Slide from './Slide'
import Cards from './Cards'

function Home() {
    return (
      <>
      <Slide/>
      <Cards/>
      </>
  )
}

export default Home