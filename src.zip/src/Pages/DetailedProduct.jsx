import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios';
import './css/detailed.css'
import { useSelector, useDispatch } from 'react-redux';
import { addToCart } from '../Redux/CartSlice';
import Review from '../Components/Review.jsx'


function DetailedProduct() {
    const { id } = useParams();
    const [card, setCard] = useState({});
    const dispatch = useDispatch();
    const navigate = useNavigate();
    let ans = useSelector(stata => stata.cartSlice.cards);
    let cartApi = `http://localhost:3000/products/${id}`;
    // =================[ INITIAL RENDER ]=================
    function renderCarts() {
        axios.get(cartApi).then((res) => {
            setCard(res.data);
        });
    }

    useEffect(() => {
        renderCarts();
    }, []);

    function handleBuy(e) {
        const check = ans.find((key) => key.id == id);
        if (check) {
            if (confirm("Product is already in cart Do you want to See")) {
                navigate(`/cart`)

            } else {

                navigate(`/payment/${card.id}`)
            }
        }
        else {
            dispatch(addToCart(card));
            navigate(`/payment/${card.id}`)
        }
    }

    return (
        <>
            <div className='parent'>
                <div className='detailed-cards'>
                    <div className='first-div part'>
                        <img src={card.imgUrl} alt="" />
                    </div>
                    <div className='second-div part'>
                        <div className='card-title'>{card.name}</div>
                        <div className='card-text1'>{card.about}</div>
                        <div className='card-text2'>{card.detailed_description}</div>
                        <div className="card-price"><h4>₹{(card.price)}</h4>
                            <button onClick={(e) => handleBuy()}>Buy Product</button>
                            <button onClick={(e) => dispatch(addToCart(card))}>Add TO Cart</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className='resf'>
                <h1></h1>
                <Review id={card.id} />
            </div>
        </>
    )
}

export default DetailedProduct