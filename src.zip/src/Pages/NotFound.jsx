import React from 'react'

function NotFound() {
  return (
    <>
    <div style={{display:"flex", justifyContent:"center", alignItems:"center",  height:"30vh", color:"red", backgroundColor:" rgb(129, 129, 234)", margin:"auto"}}>
      <div style={{fontSize:"7vw"}}>Error 404 Page NotFound</div>
    </div>
    </>
  )
}

export default NotFound